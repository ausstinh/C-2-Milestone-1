﻿using ChessBoardModel;
using System;

namespace Milestone1
{
    class Program
    {
        static Board myBoard = new Board(12);
        static void Main(string[] args)
        {
            myBoard.SetupLiveNeightbors(myBoard);
            myBoard.CalculateLiveNeighbors(myBoard);
            printBoard(myBoard);
        }
        static public void printBoard(Board myBoard)
        {
            Console.WriteLine("+ 0 + 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 +10+ 11+");
            for (int i = 0; i < myBoard.Size; i++)
            {
               
                for (int j = 0; j < myBoard.Size; j++)
                {  
                    if (myBoard.theGrid[i, j].Live)
                    {
                        Console.Write("| * ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 0)
                    {
                        Console.Write("| 0 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 1)
                    {
                        Console.Write("| 1 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 2)
                    {
                        Console.Write("| 2 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 3)
                    {
                        Console.Write("| 3 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 4)
                    {
                        Console.Write("| 4 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 5)
                    {
                        Console.Write("| 5 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 6)
                    {
                        Console.Write("| 6 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 7)
                    {
                        Console.Write("| 7 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 8)
                    {
                        Console.Write("| 8 ");
                    }
                    else if (myBoard.theGrid[i, j].LiveNeighbors == 9)
                    {
                        Console.Write("| 9 ");
                    }  
                }
                Console.Write("| +");
                Console.Write(i);
                Console.WriteLine();
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   |");
                
                Console.WriteLine();

            }
            
            Console.WriteLine("+---+---+---+---+---+---+---+---+---+---+---+---+");
            Console.WriteLine("=================================================");
        }
    }
}

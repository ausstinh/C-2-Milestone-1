﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChessBoardModel
{
    public class Cell
    {

        public int RowNumber { get; set; }
        public int ColumnNumber { get; set; }
        public bool IsVisited { get; set; }
        public bool Live { get; set; }
        public int LiveNeighbors { get; set; }

        public Cell(int r, int c)
        {
            RowNumber = r;
            ColumnNumber = r;
        }
    }
}
